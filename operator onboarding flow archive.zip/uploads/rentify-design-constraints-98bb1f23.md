# RENTIFY — DESIGN CONSTRAINTS & VISUAL LANGUAGE

*Extracted from 8 final screens (customer-side account/KYC onboarding flow: phone entry → OTP → license capture → license review → booking request confirmation). Source: Figma file `Pki794giVEu0aXtucasmEx`.*

*Note: only color is a real design system in this file (Figma variables). Typography, spacing, radii, and component patterns below are OBSERVED PATTERNS from these 8 screens, not formalized tokens — treat them as rules to follow, not a token library to reference by name, except where marked "variable."*

---

## 1. Color — real variables, use these names

| Token | Hex | Usage observed |
|---|---|---|
| `primary/500-fill` | `#e9494c` | Primary CTA buttons, active progress bar segment (implied), selected states |
| `primary/50-tint-bg` | `#fff1f1` | Full-screen tinted background (confirmation/success screen) |
| `neutral/50-page-bg` | `#f6f7f9` | Default screen background |
| `neutral/100-surface-bg` | `#eff1f3` | Camera viewfinder frame border (on dark camera screens) |
| `neutral/200-border` | `#dfe2e6` | Input borders (default/inactive), inactive progress bar segments |
| `neutral/300-divider` | `#c9cdd2` | Input borders (secondary variant — dropdowns, date fields), thin dividers between list rows |
| `neutral/400-disabled` | `#a6abb0` | Disabled/placeholder OTP digit boxes, muted secondary label under a title |
| `neutral/500-text-muted` | `#81858a` | Placeholder text, field helper microcopy |
| `neutral/600-text-secondary` | `#606366` | Secondary body copy, helper text under a field |
| `neutral/700-text-body` | `#46484a` | Default body text, active progress bar fill |
| `neutral/800-text-heading` | `#2d2e30` | Headings, primary field values, high-emphasis body text, input borders (high-contrast variant) |
| `neutral/900-text-strong` | `#1a1b1c` | Full-screen dark background (camera capture screens only) |
| `semantic/info/surface-bg` | `#e3eefb` | Info/notice banner background |
| `semantic/info/solid` | `#2a6fc4` | Info banner border |
| info banner text | `#074ea4` | Info banner body copy (not a named variable — hardcoded) |
| `semantic/warning/surface-bg` | `#fbefd6` | Distance/location pill background |
| `semantic/warning/solid` | `#c27b0a` | Distance/location pill text |
| `semantic/success/solid` | `#1e8e4e` | Rating score badge fill |
| `primary/100-tint` | `#ffe0de` / `#ffdedf` | Feature chips background, payment info card top-half, review-response pill (values differ slightly across instances — treat as the same token, flag the drift) |
| `primary/200-tint-border` | `#ffc0c1` | Feature chip border |
| `primary/300-soft` | `#ff9092` | Inset shadow on primary button (subtle depth effect) |
| `primary/400-soft-emph` | `#ff5e61` / `#ff5e60` | Payment card bottom band, "Go Drive responded" text (again, minor hex drift between uses — flag) |
| `primary/50-tint-bg` (reused) | `#fff1f1` | Sub-copy text on colored gradient cards |

**Rule:** Never use raw hex in new screens where a variable above applies. If a new color need arises that doesn't map to this list, flag it — don't invent a new hex.

**Flag:** Several tint/soft variants of primary red appear with slightly different hex values across instances of what should be the same token (e.g. `primary/100-tint` shows as both `#ffe0de` and `#ffdedf`; `primary/400-soft-emph` shows as both `#ff5e61` and `#ff5e60`). This is a 1-digit hex drift, invisible to the eye, but it means the "variable" isn't actually being applied consistently at the source — someone touched up a hex manually on some layers instead of using the token. Worth a proper Tokens Studio audit before this becomes a real system, not just documentation.

---

## 2. Typography

**Typeface:** General Sans, weights Regular / Medium / Semibold (Medium is the workhorse weight — used for ~90% of UI text; Semibold reserved for headings and button labels; Regular barely used — only OTP placeholder digits).

| Role | Size | Weight | Line-height | Tracking |
|---|---|---|---|---|
| Screen title (header bar) | 20px | Semibold | 24px | 0.2px |
| Success/hero heading | 24px | Semibold | 24–31px | 0.2–0.24px |
| Field value / button label | 16px | Medium | 24px | 0.16px |
| Field label (above input) | 14px | Medium | 20px | 0.14px |
| Body / helper copy | 14px | Medium | 20px | 0.14px |
| Secondary/caption copy | 12px | Medium | 16–18px | 0.12px |

**Rule:** Tracking is consistently ~1% of font size (e.g. 16px → 0.16px). Apply this ratio to any new text size rather than defaulting to 0.

---

## 3. Spacing & Layout

- **Screen canvas:** 412px wide (mobile), frames use `rounded-[10px]` outer corners (device mockup framing — not part of the actual app UI, ignore for real screens).
- **Horizontal page margin:** consistently **20px** both sides.
- **Standard field/section vertical gap:** 24px between grouped form fields; 28px in denser forms (license review screen).
- **Gap inside a field group (label → input):** 8px.
- **Input padding:** 14px all sides.
- **Input border radius:** 8px.
- **Card/banner border radius:** 12px.
- **Primary button:** height 60px, radius 20px (pill-ish, not fully rounded), full-width minus 20px margins (372px at this canvas width).
- **Button label vertical centering:** achieved via absolute positioning at ~30px from top of a 60px button — i.e. text is dead-center.
- **Header bar:** 74px tall, 20px padding, back icon (left) + centered title + close icon (right) — this three-part header pattern repeats on every screen except the success screen.
- **Progress bar:** 4-segment bar, 4px tall, 5px gap between segments, filled segment uses `neutral/700-text-body`, unfilled uses `neutral/200-border`. Appears directly under the header on every multi-step flow screen.
- **Status bar (12:30, wifi, signal, battery):** cosmetic device-frame chrome — do not treat as part of the design system, exclude from generated screens unless explicitly asked for full device mockups.

---

## 4. Component Patterns

**Text input**
- White fill, 0.8px border, 8px radius, 14px padding.
- Two border variants observed: `neutral/800-text-heading` (near-black, high contrast — used on the very first field of a screen) and `neutral/300-divider` (light grey — used on subsequent fields). **Inconsistency flagged**: this looks unintentional (likely a "focused first input" state applied by accident) rather than a deliberate hierarchy. Recommend Claude Design standardize on ONE border color per state (default vs. focused) rather than reproducing this literally — call this out as an open item.
- Dropdown/date variant: same input shell + trailing icon (chevron-down or calendar), 24px icon, 12px gap from text.

**Primary button**
- Fill `primary/500-fill`, white text, 60px height, 20px radius, centered label, full-width within page margins.
- Secondary/ghost variant seen once (Retake Photo vs Submit pair): transparent fill, white text, same height/radius — used only on dark full-bleed camera screens for the non-primary action.

**Selectable list row (license class picker)**
- Title (16px Medium, heading color) + subtitle (12px Medium, secondary color) stacked left, checkbox icon (39×41px) right-aligned, hairline divider between rows, all inside a bordered white container with 14px padding and internal 14px row gaps.

**Info/notice banner**
- `semantic/info/surface-bg` fill, `semantic/info/solid` 0.8px border, 12px radius, 14px padding, leading icon (32px) + 12px body text in `#074ea4`, 8px gap between icon and text.

**Full-bleed camera capture screen**
- Dark background (`neutral/900-text-strong`), transparent header overlaid on top (`neutral/800-text-heading` bar, 64px tall), viewfinder as a bordered rounded rectangle (3px border, `neutral/100-surface-bg`, 20px radius) centered on screen, instructional copy below the frame in `neutral/400-disabled`, shutter control at the bottom.

**Booking/pending confirmation card**
- Rotated slightly (~2deg) for a "photo/receipt" feel — this is a deliberate playful touch, not a bug. White card, drop shadow, 26px radius, contains image + status pill (top-left overlay, "Pending" with timer icon) + title/subtitle + date row + price row.

---

## 4b. Component Patterns — Discovery & Listing Detail (from `G0pZa154uoXr7x0lSLTz0n`)

**Filter bottom sheet**
- White surface, 20px radius, 1.5px `neutral/300-divider` border, drag-handle bar at top (60px wide hairline), section title "Filters" 24px Semibold, hairline divider under it.
- Section headers within the sheet: 20px Medium, `neutral/800-text-heading`.
- **Icon-choice cards** (vehicle type): square-ish bordered tile (114px, ~9.6px radius) with centered icon image + label below; selected state = `neutral/900-text-strong` border, unselected = `neutral/200-border`; selected label text darkens to `neutral/800-text-heading`, unselected stays `neutral/500-text-muted`.
- **Pill toggle group** (fuel type, transmission): rounded rect (8px radius, ~42-50px tall), selected = solid `neutral/800-900-text-heading/strong` fill + light text, unselected = outlined `neutral/200-border` + `neutral/400-500` muted text. This selected/unselected pattern (dark-fill-when-active, outline-when-inactive) is the standard toggle/chip pattern across the whole file — reuse it for any new binary or multi-select chip.
- **Range slider** (security deposit min/max): custom illustrated slider graphic + two pill "readout" bubbles (73px circle-ish, `neutral/200-border` outline) showing Min/Max values — this is a bespoke component, not a standard native slider; flag that Claude Design will need to approximate or simplify this rather than copy exactly.
- **Sheet footer:** fixed bottom bar, top border, two buttons side by side — "Reset" (outlined, `neutral/400-disabled` border) + primary CTA (filled, shows a live count e.g. "Show 100+ cars").

**Rating / review submission flow**
- Large tappable star row (40px stars) with a text label under it ("Good") that changes with rating value — reinforces the number with a word, consistent with the project's "plain-language conclusion first" principle already established for the operator Business section. Good pattern to carry forward.
- Free-text review box: same white/bordered/8px-radius input shell as other text fields, just tall (166px) for multi-line.
- **Tag/attribute selection** (owner conduct, vehicle condition): same dark-fill-selected / outline-unselected chip pattern as filter chips — fully consistent component reuse, good sign.
- Multi-select "what went wrong" chips use a distinct visual treatment — `neutral/100-surface-bg` fill pill, no border, `neutral/600-text-secondary` text, 12px radius. This is a *third* chip style (vs. the toggle-chip and icon-choice-card styles above) — flag as an inconsistency Claude Design should not blindly replicate three different chip styles for what's functionally the same "selectable tag" pattern.

**Vehicle listing detail page**
- Hero: full-bleed vehicle photo with gradient scrim fading to white at the bottom (`mix-blend-multiply`), floating heart/save icon (outlined) + share icon (dark circular pill) top-right, distance badge (`semantic/warning`) bottom-left overlaid on the image.
- Content sections below the hero repeat a consistent header pattern: 20px Semibold section title + hairline divider immediately under it, 12px gap. This is the same "section header + rule" pattern used in the Filter sheet — reuse it everywhere a new section needs a heading.
- Operator identity block: avatar (48px, rounded, shadowed) + shop name (16px Semibold) + owner name (14px, muted) — directly reflects the project's principle that operator/shop identity is a trust signal, not just fleet listing. Good — Claude Design should always pair a vehicle listing with this identity block, never show a vehicle "orphaned" from its operator.
- **Promo/info gradient card** ("Things to know" — free cancellation): full-bleed color gradient card (red-tone gradient here), large decorative icon bleeding off the top edge, white/tinted text, white pill "Learn More" CTA with chevron. Distinctive, high-emphasis pattern — reserve for genuinely important callouts (cancellation policy, payment protection), not routine content, or it loses impact.
- **Feature chips:** `primary/100-tint` fill, `primary/200-tint-border` border, `primary/500-fill` text — a fourth chip style, this time used purely for informational tags (not selectable). Distinct from the selectable chip styles above, which is actually fine — non-interactive tags reasonably look different from interactive ones. Keep this distinction (color-tinted = informational / dark-fill-toggle = selectable) explicit for Claude Design.
- **Review cards:** white bordered card, 12px radius, avatar + reviewer name + date + star row, review body text, optional "operator responded" pill below (tinted background, reinforces that operators can respond to reviews — matches the locked Reviews tab spec).
- **Rules list:** icon + bold title + muted description, repeated rows, no dividers between — relies on consistent vertical rhythm (16px gap) instead.
- **Sticky bottom price bar:** fixed footer, white, top border + subtle drop shadow, price + date range on the left, primary CTA pill on the right. This is the booking-flow equivalent of the earnings-tab bottom bar pattern — reuse this exact structure (info left, CTA right, fixed to viewport bottom) for any screen with a persistent primary action.



- Line-style icons throughout (Remix Icon–style naming seen in layer names: `arrow-left-line`, `close-large-line`, `calendar-line`, `arrow-down-s-line`, `checkbox-line`, `camera-4-line`, `upload-2-line`, `timer-line`, `image-line`).
- Standard icon size: **24×24px** for header/utility icons, 32px for banner icons, ~42–44px for larger tap targets (camera, upload option icons).
- **Rule for Claude Design:** use a consistent line-icon set (Material Symbols Outlined, per project standard — see note below) rather than mixing styles. The source screens use Remix-style icons, but per the project's established icon direction, **Material Symbols is the standard going forward** — Claude Design should substitute equivalents, not literally match Remix icons.

---

## 6. Tone & Content Patterns

- Microcopy is conversational, reassuring, second-person ("We'll send a one-time code to confirm it's you," "Check each field and correct anything that's wrong").
- Every data-collection screen pairs the form with a one-line trust/privacy reassurance (info banner or plain caption) — this is a deliberate trust-building pattern per the project's strategy and should be preserved on any new screen that collects sensitive data.
- Legal/consent links are inline, underlined, not separate buttons.

---

## 7. Known Gaps / Open Items (flag to Claude Design, don't silently resolve)

1. **No formal spacing or type scale exists** — the values above are reverse-engineered from 8 screens, not a documented system. Treat 8px/14px/20px/24px as the working spacing scale until a real one is defined.
2. **Input border-color inconsistency** (see Component Patterns above) — needs a decision, not replication.
3. **No documented elevation/shadow scale** — only one shadow observed (booking card), value: `0px 0px 2.58px neutral/300-divider`. Not enough data to generalize a shadow system from this alone.
4. **No dark-mode / semantic-error / semantic-success color variables observed** in this screen set — only `semantic/info` exists here. Don't invent success/error/warning colors; ask before using them if a new screen needs them.
5. **Icon set mismatch** (Remix in file vs. Material Symbols as project standard) — deliberate substitution required, not a literal copy.
6. **Three-to-four competing "chip" styles exist across the file** (dark-fill toggle, icon-choice card, flat pill, tinted informational tag) doing similar-but-not-identical jobs. This is the single biggest consistency risk for Claude Design — without explicit direction it may either replicate all four inconsistently or invent a fifth. Recommend: standardize on exactly two — a **selectable chip** (dark-fill when active / outline when inactive) and a **static/informational tag** (tinted, no interaction state) — and retire the flat `neutral/100-surface-bg` pill variant.
7. **Hex drift on primary tint/soft variables** — the same intended token renders at slightly different hex values in different places (see color table notes). Signals raw hex was hand-tweaked rather than the variable applied. Needs a real audit, not just documentation of the drift.
8. **Bespoke range-slider component** (security deposit filter) is a custom illustration-based control, not a standard UI pattern — flag to Claude Design that this needs simplification/approximation rather than exact replication, since a code-generated prototype can't easily reproduce hand-drawn slider art.

---

*Generated from Figma nodes: 1:82, 1:111, 1:142, 1:179, 1:198, 3:113, 1:264, 1:343 (file `Pki794giVEu0aXtucasmEx`) and 2791:27159, 2271:15737, 2818:30634 (file `G0pZa154uoXr7x0lSLTz0n`).*
